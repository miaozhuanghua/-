/*
SQLyog Community v13.1.6 (64 bit)
MySQL - 5.5.61 : Database - market
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`market` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `market`;

/*Table structure for table `export` */

DROP TABLE IF EXISTS `export`;

CREATE TABLE `export` (
  `eid` int(10) NOT NULL AUTO_INCREMENT,
  `egoods` varchar(30) DEFAULT NULL,
  `num` int(10) DEFAULT NULL,
  `etime` date DEFAULT NULL,
  PRIMARY KEY (`eid`)
) ENGINE=InnoDB AUTO_INCREMENT=100011 DEFAULT CHARSET=utf8;

/*Data for the table `export` */

insert  into `export`(`eid`,`egoods`,`num`,`etime`) values 
(100007,'黄瓜',100,'2020-12-29'),
(100008,'水杯',20,'2020-12-29'),
(100009,'餐巾纸',100,'2020-12-29'),
(100010,'电脑',10,'2020-12-29');

/*Table structure for table `goods` */

DROP TABLE IF EXISTS `goods`;

CREATE TABLE `goods` (
  `gid` int(10) NOT NULL AUTO_INCREMENT,
  `gname` varchar(30) DEFAULT NULL,
  `gnum` int(30) DEFAULT NULL,
  PRIMARY KEY (`gid`)
) ENGINE=InnoDB AUTO_INCREMENT=10059 DEFAULT CHARSET=utf8;

/*Data for the table `goods` */

insert  into `goods`(`gid`,`gname`,`gnum`) values 
(10053,'黄瓜',50),
(10054,'水杯',180),
(10055,'餐巾纸',200),
(10056,'毛巾',200),
(10057,'电脑',90),
(10058,'洗脸巾',200);

/*Table structure for table `imports` */

DROP TABLE IF EXISTS `imports`;

CREATE TABLE `imports` (
  `iid` int(10) NOT NULL AUTO_INCREMENT,
  `igoods` varchar(30) DEFAULT NULL,
  `num` int(10) DEFAULT NULL,
  `itime` date DEFAULT NULL,
  PRIMARY KEY (`iid`)
) ENGINE=InnoDB AUTO_INCREMENT=10040 DEFAULT CHARSET=utf8;

/*Data for the table `imports` */

insert  into `imports`(`iid`,`igoods`,`num`,`itime`) values 
(10033,'黄瓜',100,'2020-12-29'),
(10034,'水杯',200,'2020-12-29'),
(10035,'餐巾纸',300,'2020-12-29'),
(10036,'毛巾',200,'2020-12-29'),
(10037,'电脑',100,'2020-12-29'),
(10038,'洗脸巾',200,'2020-12-29'),
(10039,'黄瓜',50,'2020-12-29');

/*Table structure for table `manager` */

DROP TABLE IF EXISTS `manager`;

CREATE TABLE `manager` (
  `mid` varchar(30) DEFAULT NULL,
  `mname` varchar(30) DEFAULT NULL,
  `mpass` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `manager` */

insert  into `manager`(`mid`,`mname`,`mpass`) values 
('001','苗','12');

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `uid` int(10) NOT NULL AUTO_INCREMENT,
  `uname` varchar(30) DEFAULT NULL,
  `sex` varchar(30) DEFAULT NULL,
  `upass` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=utf8;

/*Data for the table `users` */

insert  into `users`(`uid`,`uname`,`sex`,`upass`) values 
(101,'苗壮华','女','123'),
(102,'李彦慧','女','123'),
(103,'郑','女','123'),
(105,'赵找找','男','12345');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
